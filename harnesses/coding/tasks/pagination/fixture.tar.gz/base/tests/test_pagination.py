import unittest
from pagination import collect_pages


class PaginationTests(unittest.TestCase):
    def test_single_page(self):
        self.assertEqual(collect_pages(lambda _: {"items": [1, 2]}, {}), [1, 2])

    def test_normal_two_pages_and_query(self):
        queries = []
        def fetch(params):
            queries.append(dict(params))
            if "cursor" not in params:
                return {"items": [1], "next_cursor": "second"}
            return {"items": [2], "next_cursor": None}
        query = {"status": "open"}
        self.assertEqual(collect_pages(fetch, query), [1, 2])
        self.assertEqual(query, {"status": "open"})
        self.assertEqual(queries, [{"status": "open"}, {"status": "open", "cursor": "second"}])

    def test_fetch_failure_is_propagated(self):
        error = OSError("endpoint unavailable")
        def fetch(_):
            raise error
        with self.assertRaises(OSError) as caught:
            collect_pages(fetch, {})
        self.assertIs(caught.exception, error)
