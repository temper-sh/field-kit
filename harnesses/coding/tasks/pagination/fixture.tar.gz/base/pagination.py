"""Collect a cursor-paginated endpoint using an injected fetch function."""


class PaginationCycleError(RuntimeError):
    pass


def collect_pages(fetch_page, query):
    items = []
    params = dict(query)
    while True:
        page = fetch_page(params)
        items.extend(page["items"])
        cursor = page.get("next_cursor")
        if not page["items"] or not cursor:
            return items
        params["cursor"] = cursor
