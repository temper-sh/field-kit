"""Frozen before model output; never sent to the model or visible evaluator."""
import unittest
from pagination import collect_pages, PaginationCycleError


class Acceptance(unittest.TestCase):
    def test_empty_page_and_empty_string_cursor(self):
        queries = []
        def fetch(params):
            queries.append(dict(params))
            if "cursor" not in params:
                return {"items": [], "next_cursor": ""}
            if params["cursor"] == "":
                return {"items": ["first", "first"], "next_cursor": "last"}
            return {"items": ["second"], "next_cursor": None}
        self.assertEqual(collect_pages(fetch, {"limit": 10}), ["first", "first", "second"])
        self.assertEqual(queries, [{"limit": 10}, {"limit": 10, "cursor": ""},
                                   {"limit": 10, "cursor": "last"}])

    def test_empty_terminal_page(self):
        self.assertEqual(collect_pages(lambda _: {"items": [], "next_cursor": None}, {}), [])

    def test_distinct_request_mappings_and_no_input_mutation(self):
        requests = []
        query = {"state": "open", "cursor": "start"}
        def fetch(params):
            requests.append(params)
            return {"items": [len(requests)], "next_cursor": "end" if len(requests) == 1 else None}
        self.assertEqual(collect_pages(fetch, query), [1, 2])
        self.assertEqual(query, {"state": "open", "cursor": "start"})
        self.assertEqual(requests, [query, {"state": "open", "cursor": "end"}])
        self.assertIsNot(requests[0], requests[1])
        self.assertTrue(all(params is not query for params in requests))

    def test_cycle_is_refused_before_repeated_fetch(self):
        for start, cursors, expected_calls in [(None, ["a", "b", "a"], 3),
                                               ("a", ["a"], 1), ("", [""], 1)]:
            with self.subTest(start=start):
                calls = []
                def fetch(params):
                    calls.append(dict(params))
                    if len(calls) > expected_calls:
                        raise AssertionError("Repeated cursor was fetched")
                    return {"items": ["value"], "next_cursor": cursors[len(calls) - 1]}
                with self.assertRaises(PaginationCycleError):
                    collect_pages(fetch, {} if start is None else {"cursor": start})
                self.assertEqual(len(calls), expected_calls)

    def test_later_fetch_failure_is_not_wrapped(self):
        error = ValueError("page two failed")
        def fetch(params):
            if "cursor" in params:
                raise error
            return {"items": [1], "next_cursor": "next"}
        with self.assertRaises(ValueError) as caught:
            collect_pages(fetch, {})
        self.assertIs(caught.exception, error)
