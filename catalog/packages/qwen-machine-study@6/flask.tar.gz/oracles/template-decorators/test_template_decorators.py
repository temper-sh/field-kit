"""Decorator contract tested through registration, direct calls and real Jinja."""
import pytest
from flask import Blueprint, Flask, render_template_string


KINDS = ["filter", "test", "global"]
FORMS = ["bare", "empty", "none", "positional-name", "keyword-name"]


def function(kind):
    def marker(value):
        """The registered function remains an ordinary callable."""
        return value == "accepted" if kind == "test" else "marked:" + value
    return marker


def register(owner, kind, form, func):
    prefix = "app_template_" if isinstance(owner, Blueprint) else "template_"
    method = getattr(owner, prefix + kind)
    if form == "bare":
        return method(func), func.__name__
    if form == "empty":
        return method()(func), func.__name__
    if form == "none":
        return method(None)(func), func.__name__
    if form == "positional-name":
        return method("public_marker")(func), "public_marker"
    return method(name="public_marker")(func), "public_marker"


def mapping(app, kind):
    return getattr(app.jinja_env, {"filter": "filters", "test": "tests",
                                  "global": "globals"}[kind])


def render(app, kind, name):
    if kind == "filter":
        template = '{{ "accepted"|' + name + ' }}'
        expected = "marked:accepted"
    elif kind == "test":
        template = '{% if "accepted" is ' + name + ' %}yes{% endif %}'
        expected = "yes"
    else:
        template = '{{ ' + name + '("accepted") }}'
        expected = "marked:accepted"
    with app.app_context():
        assert render_template_string(template) == expected


@pytest.mark.parametrize("owner_kind", ["app", "blueprint"])
@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("form", FORMS)
def test_forms_register_and_preserve_callable(owner_kind, kind, form):
    app = Flask(__name__)
    owner = app if owner_kind == "app" else Blueprint("feature", __name__)
    func = function(kind)
    decorated, name = register(owner, kind, form, func)
    assert decorated is func
    assert decorated.__name__ == "marker"
    assert decorated.__doc__ == func.__doc__
    assert decorated("accepted") == (True if kind == "test" else "marked:accepted")
    if kind == "test":
        assert decorated("rejected") is False
    if owner_kind == "blueprint":
        assert name not in mapping(app, kind)
        app.register_blueprint(owner, url_prefix="/feature")
    assert mapping(app, kind)[name] is func
    if name != func.__name__:
        assert func.__name__ not in mapping(app, kind)
    render(app, kind, name)


@pytest.mark.parametrize("kind", KINDS)
def test_blueprint_reused_on_independent_apps(kind):
    bp = Blueprint("feature", __name__)
    func = function(kind)
    _, name = register(bp, kind, "bare", func)
    apps = [Flask("first"), Flask("second")]
    for app in apps:
        assert name not in mapping(app, kind)
    for app in apps:
        app.register_blueprint(bp)
        assert mapping(app, kind)[name] is func
        render(app, kind, name)


@pytest.mark.parametrize("owner_kind", ["app", "blueprint"])
@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("form", ["bare", "empty", "keyword-name"])
def test_late_registration_still_refused(owner_kind, kind, form):
    app = Flask(__name__)
    if owner_kind == "blueprint":
        owner = Blueprint("feature", __name__)
        app.register_blueprint(owner)
    else:
        owner = app
        app.test_client().get("/").close()
    with pytest.raises(AssertionError):
        register(owner, kind, form, function(kind))


@pytest.mark.parametrize("owner_kind", ["app", "blueprint"])
@pytest.mark.parametrize("kind", KINDS)
def test_add_registration_api_unchanged(owner_kind, kind):
    app = Flask(__name__)
    owner = app if owner_kind == "app" else Blueprint("feature", __name__)
    func = function(kind)
    prefix = "add_app_template_" if owner_kind == "blueprint" else "add_template_"
    getattr(owner, prefix + kind)(func, name="public_marker")
    if owner_kind == "blueprint":
        assert "public_marker" not in mapping(app, kind)
        app.register_blueprint(owner)
    assert mapping(app, kind)["public_marker"] is func
    render(app, kind, "public_marker")
