"""Public behavior only; each test gets a fresh Context even for broken controls."""
import asyncio
from contextvars import Context
from functools import wraps

import asgiref.sync  # Mandatory dependency: the async cases must never skip.
import pytest
from flask import Flask, Response, current_app, g, has_app_context
from flask import has_request_context, request, session, stream_with_context


def isolated(test):
    @wraps(test)
    def run(*args, **kwargs):
        return Context().run(test, *args, **kwargs)
    return run


def application():
    app = Flask(__name__)
    app.config.update(TESTING=True, SECRET_KEY="oracle-test-only")
    return app


@pytest.mark.parametrize("asynchronous", [False, True], ids=["sync", "async"])
@pytest.mark.parametrize("form", ["iterator", "decorator"])
@pytest.mark.parametrize("early_close", [False, True], ids=["exhaust", "close"])
@isolated
def test_lazy_body_and_cleanup(asynchronous, form, early_close):
    app = application()
    marker = object()
    events = []
    teardown_effects = []

    @app.teardown_request
    def request_cleanup(error):
        if "first" in events:
            teardown_effects.append("request")

    @app.teardown_appcontext
    def app_cleanup(error):
        if "first" in events:
            teardown_effects.append("application")

    def response():
        g.marker = marker
        session["label"] = "kept-session"
        req = request._get_current_object()

        def check_context():
            assert current_app._get_current_object() is app
            assert request._get_current_object() is req
            assert request.args["q"] == "kept-request"
            assert session["label"] == "kept-session"
            assert g.marker is marker

        def body(prefix):
            try:
                check_context()
                events.append("first")
                yield prefix + ":" + request.args["q"]
                check_context()
                events.append("second")
                yield ":" + session["label"]
            finally:
                check_context()
                events.append("closed")

        if form == "iterator":
            wrapped = stream_with_context(body("start"))
        else:
            wrapped = stream_with_context(body)("start")
        assert events == [], "wrapping must not consume the response body"
        return Response(wrapped)

    async def async_view():
        await asyncio.sleep(0)
        return response()

    app.add_url_rule("/stream", view_func=async_view if asynchronous else response)
    rv = app.test_client().get("/stream?q=kept-request", buffered=False)
    try:
        assert rv.status_code == 200
        assert next(rv.response) == b"start:kept-request"
        assert events == ["first"]
        if not early_close:
            assert b"".join(rv.response) == b":kept-session"
    finally:
        rv.close()
    assert events == (["first", "closed"] if early_close else
                      ["first", "second", "closed"])
    assert "request" in teardown_effects
    assert "application" in teardown_effects
    assert not has_request_context()
    assert not has_app_context()


@pytest.mark.parametrize("early_close", [False, True], ids=["exhaust", "close"])
@isolated
def test_async_stream_with_preserving_client(early_close):
    app = application()

    @app.get("/")
    async def index():
        await asyncio.sleep(0)
        session["value"] = "session"

        @stream_with_context
        def body():
            yield request.path
            yield session["value"]

        return Response(body())

    with app.test_client() as client:
        rv = client.get("/", buffered=False)
        try:
            assert next(rv.response) == b"/"
            if not early_close:
                assert b"".join(rv.response) == b"session"
        finally:
            rv.close()
        assert request.path == "/"
    assert not has_request_context()
    assert not has_app_context()


@isolated
def test_async_stream_preserves_enclosing_application_context():
    app = application()
    marker = object()

    @app.get("/")
    async def index():
        await asyncio.sleep(0)
        assert g.marker is marker

        def body():
            assert g.marker is marker
            yield request.path

        return Response(stream_with_context(body()))

    with app.app_context():
        g.marker = marker
        rv = app.test_client().get("/")
        try:
            assert rv.get_data() == b"/"
        finally:
            rv.close()
        assert g.marker is marker
        assert has_app_context()
        assert not has_request_context()
    assert not has_app_context()


@isolated
def test_async_stream_body_exception_releases_contexts():
    app = application()
    closed = []

    @app.get("/")
    async def index():
        await asyncio.sleep(0)

        def body():
            try:
                yield request.path
                raise ValueError("body failed")
            finally:
                closed.append(request.path)

        return Response(stream_with_context(body()))

    rv = app.test_client().get("/", buffered=False)
    try:
        assert next(rv.response) == b"/"
        with pytest.raises(ValueError, match="body failed"):
            next(rv.response)
    finally:
        rv.close()
    assert closed == ["/"]
    assert not has_request_context()
    assert not has_app_context()


@isolated
def test_async_custom_iterator_closed_on_partial_response():
    app = application()
    closed = []

    class Body:
        def __iter__(self):
            return self

        def __next__(self):
            return request.path

        def close(self):
            closed.append(request.path)

    @app.get("/")
    async def index():
        await asyncio.sleep(0)
        return Response(stream_with_context(Body()))

    rv = app.test_client().get("/", buffered=False)
    assert next(rv.response) == b"/"
    rv.close()
    assert closed and all(value == "/" for value in closed)
    assert not has_request_context()
    assert not has_app_context()


@isolated
def test_requires_active_request():
    with pytest.raises(RuntimeError):
        stream_with_context(iter(["body"]))
